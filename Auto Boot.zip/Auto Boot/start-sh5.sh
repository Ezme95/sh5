#!/bin/bash

echo "Checking Wi-Fi ..."
until ping -c1 google.com &>/dev/null; do
    echo "Waiting for network..."
    sleep 5
done

echo "Wi-Fi connected. Starting app..."
sleep 10

# Set environment variables for real GUI session
export DISPLAY=:0
export XAUTHORITY=/home/pi/.Xauthority
export XDG_RUNTIME_DIR="/run/user/$(id -u)"

cd /home/pi/Documents/sh5/sh5/
npm start


